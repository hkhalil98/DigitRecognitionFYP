# Base project for using GNNs on human-aware navigation
This repository holds the basic files to train a GNN model.



## Generation fo the dataset
datasetGeneration.py

## Running training file

> python3 train.py



